<?php

namespace App\Livewire\Teacher\Finance;

use Livewire\Component;

class Index extends Component
{
    public function render()
    {
        return view('teacher.finance.index');
    }
}
