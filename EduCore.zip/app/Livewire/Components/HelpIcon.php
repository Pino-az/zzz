<?php

namespace App\Livewire\Components;

use Livewire\Component;

class HelpIcon extends Component
{
    public function render()
    {
        return view('components.help-icon');
    }
}
